started sets came 2012-16 from some requester hit
later found other games similar idea
got ui setup euphoria but never did much logic
could have one program to create shape images one to play game
should have templates and snippits by now for reading cfg maps but not really
don't even remember the rules andnever found a simple download game
think I was using one set of images and changing colors on the fly?
it's why I had to upgrade euQt to Qt 4.6

	diamond_open_.png
	diamond_solid_.png
	diamond_striped_.png

	oval_open_.png
	oval_solid_.png
	oval_striped_.png

	squiggle_open_.png
	squiggle_solid_.png
	squiggle_striped_.png

	pixblank.png
	red.png
needd to figure out a few things before doing red version
might be draw is the way to go to build all possible shapes & colors selected
allows it to be user changable like grid game

variable grid usually 4x by 3y you have to click what is missing in a set in the grid
then those are replaced by others untill you have all the sets?
have potential to have unsolvable sets, hints, time limits
easy or harder sets. pretty addicting


from eu readme
	s14726p4:10 saw the Sets card game the first time a few weeks ago
	on MTurk. I am spectacularly bad at it.
	found a few web pages you can play it or analize it. see links
	
	want to do an implementation. couldn't find a javascript that worked
	not sure what GUI would be easiest or how to implement it
	there are android apps that let you multiplayer or single player
	faithfully or modified from the standard.
	
	simple enough rules, you have cards, I think 54?
	3 colors   red/orange   blue/purple  green
		actually only one color each but some games have one some the other
	3 shapes   diamonds  ovals  squiggles
	3 shades   open     lined  solid
	you pick 3 cards from a field of 12 I think is standard 3x3
	  3 across by 3 down
	each card has either 1, 2 or 3 of a shape in a color in a shading
	
	the cards that make a set
	a one card a two card and a three card
	3 of the same color different shapes same shading
	3 of the same color same shape different shading
	3 of different colors same shape same shading
	one of the permutations of number shape color shading 
	
	when you pick a set, the deck is reduced by 3
	the 3 cards you picked are replaced in the grid
	if the cards you pick are not a set you are shown the error
	and maybe highlight two or one that is wrong 
	your score is updated
	some games have a find set button
	some games have a hint button
	one game has more than 3 shapes and more than 3 colors
	one game has an add 3 cards that makes the grid 4x3 if you're stuck
	
		 o0o0o0		  e		   mw	
		o0o0o0o0	e3e3e     wm wmw
		 o0o0o0	      e		mwm  wmwm
	
	
	
	
	strategy:
	look for all the same color & shape seems to be the easiest
	start with 3 then a different color same or different shape 2 card
	then can see if any of the 1 cards have the required match
	some people are no doubt better at this than others
	a continuous hint/autoplay mode to highlight matches might be nice
	count off one red two blue three green or variations
	one red open, two green shaded, three blue solid
	while picking same shape or different shape each time
	since I am so bad at it, I shouldn't be suggesting stategys
	but this works for me a little better than blankly staring
	sometimes there is only one or two of a 1, 2 or 3 on the grid
	this makes it simpler to know what else to pick or if there are none
	count off one shade two open three solid or whatever
	  while thinking same color or different color
	maybe for some the likely sets just jump out like sterograms
	easy pick is all 1 or all 2 or all 3 of the same or different shape or color
	either all the same or all different is the one rule
	
	links:
	http://en.wikipedia.org/wiki/SET_%28game%29
	
	inventer of the game?
	setgame.com
	
	sets in flash
	http://tao-game.dimension17.com/
	
	good, single player, has add 3 card feature
	http://smart-games.org/en/set/start/
	
	make real life images theme based
	can strech the idea of shape/shade/color
	  maybe do brands to get differences
	  food is tough because of the difficulty to get good images
	  and where to get them.
	food:
	sports:
	nature:
	
	create/borrow cardd
	missins some, more efficent to overlay to get 1,2,3
	wonder if I can do something with a canvas to draw in realtime
	rather than try to piece them together from partial images?
	
		diamond_open_red.png
	diamond_open_green.png
		diamond_open_blue.png
	
	diamond_solid_red.png
		diamond_solid_green.png
	diamond_solid_blue.png
	
		diamond_striped_red.png
	diamond_striped_green.png
	diamond_striped_blue.png
	
		oval_open_red.png
		oval_open_green.png
	oval_open_blue.png
	
	oval_solid_red.png
	oval_solid_green.png
		oval_solid_blue.png
	
	squiggle_open_red.png
		squiggle_open_green.png
		squiggle_open_blue.png
	
	squiggle_solid_red.png
		squiggle_solid_green.png
	squiggle_solid_blue.png
	
		squiggle_striped_red.png
		squiggle_striped_green.png
		squiggle_striped_blue.png
	
	raw_card[]
	grid_cards[]
	burned_cards[]
	
	help()
		show_instructions
	
	draw_grid()
		make sure at least one set can be found?
		or, have a swap 3 cards feature or swap selected one or two
		if keeping score deduct points if there was a set
	
	
	 create_window()
	 create_grid()
	 create_deck()
	 
	 play()
		 loop
			 draw_grid()
			 while <3  get_input()
			 check_oick()
			 if aset()
			 else ahint()
			 else anerror()
			 update_grid()
		 end loop
	
	  exit else new_game()
	
	eot 

http://smart-games.org/en/set/submit_set
http://smart-games.org/en/set/start
Mark 3 cards with mouse-click (or use keys Q-R, A-F, Z-V, 3) 
Cards in deck: 69
completely awful at seeing matching sets again after not doing it a few years
maybe a hint mode to flash good combos auto play style
could create board with text also in rich view
 or just text cards with variable size text vrs all shape or all text

it's becomming impossible for me to juggle this many things
I start building a set and get stuck figuring out what is missing
 or how to switch to use what remains

https://www.setgame.com/set
https://puzzles.setgame.com

guess the logic semi independent from basic creating a random deck and displaying a subset
removing cards and replacing them from what's left
composition of the cards will depend on how many rows
not sure I really want to get into doing the whole game
every time I program I miss hits and productivity drops
4x3 4x4 and standard 
3 color red green blue
3 shape triangle oval squiggle
3 composition open strip solid
1 two or 3 of each on each card
is 69 cards?
decide how many cards in deck, populate cords, shuffle
everything else flows from what is on display. can click on/off cards
3td choice validates and either replaces set and cirrent last found display
or notifies is not set either way cards unselected
game timer counts up, stats accumulated, hints possible, cheat pick one another another
conceed or stuck stalemste, cheat swap in new card at random
force timed select next set or computer will
auto play mode blink selections 
animate set removal
started as actual card game?
ftp://tcl.activestate.com/pub/tcl/nightly-cvs/
ftp://tcl.activestate.com/pub/tcl/nightly-cvs/tclapps-20140217.tar.gz
http://pbg.cs.illinois.edu/papers/set.pdf

https://www.thedatingdivas.com/sexy-card-game/

REBOL Developer Forum (AltME World)
http://rebol.net/altweb/rebol3/chat526.html

ICarii	sudoku-solver 0.1.2 released - this successfully solves the mensa puzzle. 
http://rebol.mustard.co.nz/sudoku-solver.r notes: added some even harder puzzles to test upcoming XY-Chains and Swordfish
posted this to the calendat back in July. http://rebol/mustard.co.nz/rebtower-0.0.4.zip
http://web.archive.org/web/20081002222159/http://rebol.mustard.co.nz/

http://www.rebol.org/view-script.r?script=playing-card-framework.r
http://re-bol.com/rebol.html#section-10.18
http://www.rebol.org/download-a-script.r?script-name=playing-cards.r
https://stackoverflow.com/questions/4073722/rebol-view-how-to-assign-images-to-layout-already-created

deck of Uno cards
https://www.minigames.com/category/Cards

https://arstechnica.com/gaming/2018/12/keyforge-the-red-hot-card-game-where-every-deck-is-unique-and-unchangeable/








